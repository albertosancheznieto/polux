package com.albertosancheznieto.polux.app;

import com.albertosancheznieto.polux.entity.CustomerComerzzia;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.catalina.Authenticator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

@Component
public class FidelizadoService {

    public static final String PATH_OBTENER_FIDELIZADOS = "https://hiperusera.saas.comerzzia.com/api/v2/loyalty/customers";

    private static final HttpClient httpClient = HttpClient.newBuilder()
            .authenticator(new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(
                            "user",
                            "password".toCharArray());
                }

            })
            .connectTimeout(Duration.ofSeconds(10))
            .build();

   //@Autowired
    //private RestTemplate restTemplate;

    public void buscarFidelizado() {

    }

    public void obtenerFidelizados() {
        //CustomerComerzzia[] customersComerzzia = restTemplate.getForObject(PATH_OBTENER_FIDELIZADOS, CustomerComerzzia[].class);
        //return Arrays.asList(customersComerzzia)
        //System.out.println("Cliente: " + customersComerzzia.toString());

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(PATH_OBTENER_FIDELIZADOS))
                .version(HttpClient.Version.HTTP_2)
                .GET()
                .build();
        try {
            HttpResponse<InputStream> response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
            if (response.statusCode() == HttpStatus.OK.value()) {
                CustomerComerzzia responseElement = new ObjectMapper().readValue(response.body(), CustomerComerzzia.class);
            } else {
                // process incorrect response
            }
        } catch (IOException e) {
            // process error
        } catch (InterruptedException e) {
            // process error
        }

    }

    private void obtenerToken() {
        /*
        String encodedClientData =
                Base64Utils.encodeToString("bael-client-id:bael-secret".getBytes());
        Mono<String> resource = client.post()
                .uri("localhost:8085/oauth/token")
                .header("Authorization", "Basic " + encodedClientData)
                .body(BodyInserters.fromFormData("grant_type", "client_credentials"))
                .retrieve()
                .bodyToMono(JsonNode.class)
                .flatMap(tokenResponse -> {
                    String accessTokenValue = tokenResponse.get("access_token")
                            .textValue();
                    return client.get()
                            .uri("localhost:8084/retrieve-resource")
                            .headers(h -> h.setBearerAuth(accessTokenValue))
                            .retrieve()
                            .bodyToMono(String.class);
                });
        return resource.map(res ->
                "Retrieved the resource using a manual approach: " + res);
        */
    }



}